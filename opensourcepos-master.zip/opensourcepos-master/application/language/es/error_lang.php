<?php 

$lang["error_no_permission_module"] = "No tienes permiso para accesar el módulo llamado";
$lang["error_unknown"] = "desconocido";
