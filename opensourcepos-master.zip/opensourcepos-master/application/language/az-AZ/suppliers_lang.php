<?php 

$lang["suppliers_account_number"] = "Hesab №";
$lang["suppliers_agency_name"] = "Agentliyin Adı";
$lang["suppliers_cannot_be_deleted"] = "Seçilmiş Təchizatçı (lar) silinə bilmədi. Bir və ya birdən çox satışlar var.";
$lang["suppliers_category"] = "Bölmə";
$lang["suppliers_company_name"] = "Kompaniyanın Adı";
$lang["suppliers_company_name_required"] = "Şirkətin Adı - yazılması vacib sahə.";
$lang["suppliers_confirm_delete"] = "Siz əminsiniz ki seçilmiş təchizatçı (lar) ı silmək istəyirsiniz?";
$lang["suppliers_confirm_restore"] = "Seçilmiş təchizatçı (lar) bərpa etmək istədiyinizə əminsinizmi?";
$lang["suppliers_cost"] = "Maliyə Təchizatçı";
$lang["suppliers_error_adding_updating"] = "Təchizatçı əlavə et / yenilə XƏTA.";
$lang["suppliers_goods"] = "Məhsullar Təchizatçı";
$lang["suppliers_new"] = "Yeni Təchizatçı";
$lang["suppliers_none_selected"] = "Siz silmək üçün heç bir təchizatçı (lar)  seçmədiniz.";
$lang["suppliers_one_or_multiple"] = "Təchizatçı (lar)";
$lang["suppliers_successful_adding"] = "Siz Təchizatçını uğurla əlavə etdiniz";
$lang["suppliers_successful_deleted"] = "Siz uğurla sildiniz";
$lang["suppliers_successful_updating"] = "Siz uğurla Təchizatçını yenilədiniz";
$lang["suppliers_supplier"] = "Təchizatçı";
$lang["suppliers_supplier_id"] = "Kimlik";
$lang["suppliers_tax_id"] = "Vergi İD";
$lang["suppliers_update"] = "Təchizatçı Yenilənməsi";
