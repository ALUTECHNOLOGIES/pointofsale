<?php 

$lang["suppliers_account_number"] = "Račun br.";
$lang["suppliers_agency_name"] = "Naziv djelatnosti";
$lang["suppliers_cannot_be_deleted"] = "Ne mogu obrisati odabranog dobavljača. Jedan ili više odabranih dobavljača ima prodaju.";
$lang["suppliers_category"] = "";
$lang["suppliers_company_name"] = "Naziv tvrtke";
$lang["suppliers_company_name_required"] = "Naziv tvrtke je potreban";
$lang["suppliers_confirm_delete"] = "Jeste li ste sigurni da želite obrisati odabranog dobavljača?";
$lang["suppliers_confirm_restore"] = "";
$lang["suppliers_cost"] = "";
$lang["suppliers_error_adding_updating"] = "Greška kod dodavanja/ažuriranja dobavljača";
$lang["suppliers_goods"] = "";
$lang["suppliers_new"] = "Novi dobavljač";
$lang["suppliers_none_selected"] = "Niste odabrali nijednog dobavljača za brisanje";
$lang["suppliers_one_or_multiple"] = "Dobavljač(i)";
$lang["suppliers_successful_adding"] = "Uspješno ste dodali dobavljača";
$lang["suppliers_successful_deleted"] = "Uspješno ste obrisali dobavljača";
$lang["suppliers_successful_updating"] = "Uspješno ste ažurirali dobavljača";
$lang["suppliers_supplier"] = "Dobavljač";
$lang["suppliers_supplier_id"] = "ID";
$lang["suppliers_tax_id"] = "";
$lang["suppliers_update"] = "Ažuriranje dobavljača";
