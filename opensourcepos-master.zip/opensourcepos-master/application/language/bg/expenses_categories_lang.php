<?php 

$lang["category_name_required"] = "Expense Category name required";
$lang["expenses_categories_add_item"] = "Add Category";
$lang["expenses_categories_cannot_be_deleted"] = "Could not delete Category Expense(s)";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Are you sure you want to delete the selected Expense Category?";
$lang["expenses_categories_confirm_restore"] = "";
$lang["expenses_categories_description"] = "Category Description";
$lang["expenses_categories_error_adding_updating"] = "Error adding/updating Expense Category";
$lang["expenses_categories_info"] = "Category Expense Info";
$lang["expenses_categories_name"] = "Category Name";
$lang["expenses_categories_new"] = "New Category";
$lang["expenses_categories_no_expenses_categories_to_display"] = "No Category to display";
$lang["expenses_categories_none_selected"] = "You have not selected any Category Expense";
$lang["expenses_categories_one_or_multiple"] = "Category Expense";
$lang["expenses_categories_quantity"] = "Quantity";
$lang["expenses_categories_successful_adding"] = "Expense Category add successful";
$lang["expenses_categories_successful_deleted"] = "Expense Category delete successful";
$lang["expenses_categories_successful_updating"] = "Expense Category update successful";
$lang["expenses_categories_update"] = "Update Category";
