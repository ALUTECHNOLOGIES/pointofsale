<?php 

$lang["tables_all"] = "הכול";
$lang["tables_columns"] = "עמודות";
$lang["tables_hide_show_pagination"] = "הסתר / הצג מספור דפים";
$lang["tables_loading"] = "טוען, אנא המתן ...";
$lang["tables_page_from_to"] = "מציג {0} ל {1} מתוך {2} שורות";
$lang["tables_refresh"] = "רענן";
$lang["tables_rows_per_page"] = "{0} שורות לדף";
$lang["tables_toggle"] = "החלף";
